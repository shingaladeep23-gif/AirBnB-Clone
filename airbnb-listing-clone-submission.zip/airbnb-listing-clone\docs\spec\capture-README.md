# How to capture the reference content — 5 minutes, one paste

Jim (jim-mt2rp4pg), 21 Aug 2026.

Everything in `BELOW-FOLD-SPEC.md` marked **PENDING** is a string nobody has been
able to read: the host name, the five review bodies, the description, the amenity
list, the six category scores, the highlights, the chip quotes, the co-host names,
the things-to-know copy. This script gets all of them in one go.

It only works from **a real Chrome window that you are driving yourself.** The
reference is behind Vercel Attack Challenge Mode + BotID, so curl, PowerShell and
Playwright all get 429 — that has been proven three ways, please don't retry them.

---

## Before you start (30 seconds, once)

1. Open **https://airbnb-clone-umber-two.vercel.app** in normal Chrome. Wait until
   the listing is fully rendered — not the "Loading…" shell.
2. Press **F12** → **Console** tab.
3. **Chrome will refuse the first paste into the console.** It shows a warning and
   asks you to type a phrase. Type exactly:

   ```
   allow pasting
   ```

   and press Enter. You only ever do this once per profile.

---

## The five runs

Each run captures **whatever is on screen right now**. The script figures out on
its own whether a modal is open and captures the modal instead of the page — so
all you do is open the right thing first, then run it.

For **run 1** you paste the whole file. For runs 2–5 you just type a one-liner,
because the script leaves itself behind as `__CAPTURE__`.

| # | Open this first | Then run | Gets us |
|---|---|---|---|
| 1 | Nothing — the plain listing page | paste all of `capture-content.js` | Host name, highlights, description, 5 review cards, chip labels + quotes, category scores, co-hosts, things-to-know, footer, and every section's geometry |
| 2 | Click **"Show all N amenities"** | `__CAPTURE__('amenities')` | The full amenity list (it is NOT in the page — only in the modal) |
| 3 | Close that, click **"Show all 19 reviews"** | `__CAPTURE__('reviews')` | All 19 review bodies, names, dates |
| 4 | Close that, click **"Show all photos"** | `__CAPTURE__('tour')` | Photo Tour: room-group headings and the exact photo order |
| 5 | From the tour, click any single photo | `__CAPTURE__('lightbox')` | Lightbox: counter format, button labels, arrow controls |

> Runs 2–5 only work if you have **not reloaded the page** since run 1. If you do
> reload (the Photo Tour changes the URL to `?modal=PHOTO_TOUR_SCROLLABLE`, and
> opening that link directly counts as a fresh load), just paste the whole file
> again — passing a label like `__CAPTURE__('tour')` afterwards is optional, the
> first paste self-labels as `listing`.

### After each run

A dark panel opens over the page with everything in one textarea.

- **Copy all** → paste it into a new file at
  `D:\PlayPower Assignment\_reference\spec\captured\capture-<label>.txt`
- or **Download 1 file** → it lands in Downloads as `capture-<label>.txt`, move it
  to that same folder.
- **Close** dismisses the panel. It never captures itself.

Both buttons give the same content. One file per run, five files total. Chrome
blocks *automatic* repeat downloads, which is why nothing downloads until you click.

---

## What you get in each file

```
# AIRBNB REFERENCE CAPTURE     ← url, title, doc height, viewport, fonts, counts
## HEADINGS                    ← every h1–h6 in order, with its y position
## IMAGES                      ← every image: filename, alt text, x/y/w/h
## NODES                       ← y | x | w | h | tag | attrs | text
```

The `NODES` block is the useful one. Because it carries **geometry as well as
text**, it doubles as the below-the-fold measurement pass — which means it also
settles the open question in `BELOW-FOLD-SPEC.md` §16 about which sections are
over-estimated, and whether the calendar section exists at all. Look for the `y`
of each `SECTION` / `#id` row.

The panel has a **Text only** toggle if you want the strings without the numbers.

---

## Two things it deliberately does not do

**It never reads `getComputedStyle`.** On this site that call is sabotaged — it
returns an empty declaration with `length === 0`, verified both from an extension's
isolated world and from a script injected into the page's main world. So no
colours, font sizes, padding or shadows can come out of this, by anyone. Those
still have to be matched visually against screenshots. What does work, and what
this script uses, is text, attributes, image sources and `getBoundingClientRect`.

**It never records class names or serialises markup.** The reference's class names
are obfuscated build output and copying them would be lift-and-shift, which risks
disqualification on this assignment. Capturing text and measurements is the
sanctioned workflow; capturing structure is not, so the script cannot do it even
by accident.

It also never clicks anything and never triggers `alert`/`confirm`/`prompt` — a
modal dialog would freeze the DevTools bridge. You open the modals; it only reads.

---

## If something goes wrong

| Symptom | Fix |
|---|---|
| Paste is refused | Type `allow pasting` in the console first (see above) |
| Panel doesn't appear | Check the console line starting `[capture 1.0]`. If it isn't there, the paste didn't run — re-paste. |
| Textarea is too big to copy reliably | Use **Download 1 file** instead |
| You need it back in the console | `window.__CHUNKS__` gives the count, `__CHUNK__(0)`, `__CHUNK__(1)`, … each return ~1KB. Deliberately small — tool output truncates around 1.2KB. |
| Captured the wrong thing | The header line `root : page` vs `root : dialog` tells you which it grabbed. Re-open the modal and re-run. |
| It seems to hang | It self-terminates at 40s (inside the 45s bridge timeout). A normal run is ~1–3 seconds. |

Smoke-tested against a synthetic fixture covering lazy images, a scrollable modal,
`aria-hidden` subtrees and a `display:none` overlay. Both a page run and a modal
run complete in under a second and neither leaks the other's content.

---

## The one-line version

> Open the reference in normal Chrome, F12 → Console, type `allow pasting` and
> Enter, then paste the whole of `_reference/spec/capture-content.js`, click
> **Download 1 file**, and repeat with `__CAPTURE__('amenities')`,
> `__CAPTURE__('reviews')`, `__CAPTURE__('tour')` and `__CAPTURE__('lightbox')`
> after opening each of those in turn — five files into
> `_reference/spec/captured/`.
